# Mikasa AI Chat App

Aplikasi chat AI dengan karakter-karakter unik yang dapat berinteraksi dengan pengguna. Dibangun dengan React, TypeScript, dan Tailwind CSS.

## 🚀 Fitur Utama

- **Chat dengan Karakter AI**: Interaksi dengan 10+ karakter unik (Mikasa, Minnie, Nailong, Anya Forger, dll)
- **Feed Sosial**: Buat dan bagikan postingan seperti TikTok
- **Profil Pengguna**: Edit profil dan upload foto
- **Mode Demo**: Coba aplikasi tanpa registrasi
- **Responsive Design**: Optimal di desktop dan mobile
- **Dark Mode**: Tema gelap dan terang

## 🎯 Karakter Chat

- **Mikasa** - Karakter pria yang protektif dan siap membantu
- **Minnie** - Teman baik yang ramah dan ceria
- **Nailong** - Dinosaurus kuning yang lucu dan gembul
- **Anya Forger** - Gadis imut yang suka cerita dongeng
- **Pipi** - Penguin lucu yang suka es krim
- **Bubu** - Beruang gembul yang suka nyanyi
- **Nana** - Gadis permen yang ceria dan manis
- **Power Ranger** - Pahlawan kostum warna-warni
- **Ultraman** - Raksasa baik hati yang jaga bumi
- **BoBoiBoy** - Pahlawan muda super cepat

## 🛠️ Teknologi yang Digunakan

- **React 18** - Framework JavaScript
- **TypeScript** - Type safety
- **Vite** - Build tool yang cepat
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library
- **Supabase** - Backend as a Service
- **OpenAI API** - AI chat completion
- **Gemini API** - Alternative AI service

## 📦 Instalasi

1. **Clone repository**
   ```bash
   git clone https://github.com/username/mikasa-chat-app.git
   cd mikasa-chat-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Setup environment variables**
   ```bash
   cp .env.example .env
   # Edit .env dengan API keys Anda
   ```

4. **Jalankan aplikasi**
   ```bash
   npm run dev
   ```

5. **Buka browser**
   ```
   http://localhost:5173
   ```

## 🔧 Konfigurasi

### Environment Variables

Buat file `.env` di root project:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_OPENAI_API_KEY=your_openai_api_key
VITE_GEMINI_API_KEY=your_gemini_api_key
```

### Supabase Setup

1. Buat project di [Supabase](https://supabase.com)
2. Dapatkan URL dan API key
3. Setup database tables sesuai migration files

## 📱 Cara Menggunakan

### Mode Demo
1. Buka aplikasi
2. Klik "Coba Demo Gratis"
3. Mulai chat dengan karakter pilihan

### Mode Login
1. Klik "Mulai Sekarang"
2. Daftar/Login dengan email
3. Nikmati fitur lengkap

### Feed Sosial
1. Navigasi ke tab "Feed"
2. Klik foto profil untuk buat postingan
3. Ketik konten dan klik "Posting"
4. Postingan akan tersimpan secara permanen

## 🎨 Customization

### Menambah Karakter Baru
Edit file `src/services/characterResponses.ts`:

```typescript
export const characterResponses: Record<string, CharacterResponse> = {
  'new-id': {
    greeting: 'Halo! Aku [Nama Karakter]!',
    personality: 'Deskripsi kepribadian',
    responses: [
      'Respons 1',
      'Respons 2',
      // ... lebih banyak respons
    ]
  }
};
```

### Mengubah Tema
Edit file `src/index.css` atau komponen individual untuk custom styling.

## 📂 Struktur Project

```
src/
├── components/          # React components
│   ├── ChatList.tsx    # Daftar chat
│   ├── FeedPage.tsx    # Halaman feed
│   ├── ProfilePage.tsx # Halaman profil
│   └── ...
├── hooks/              # Custom React hooks
├── services/           # API services
├── types/              # TypeScript types
└── utils/              # Utility functions
```

## 🤝 Kontribusi

1. Fork repository
2. Buat feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📄 Lisensi

Distributed under the MIT License. See `LICENSE` for more information.

## 📞 Kontak

- **Email**: your-email@example.com
- **GitHub**: [@yourusername](https://github.com/yourusername)
- **Project Link**: [https://github.com/yourusername/mikasa-chat-app](https://github.com/yourusername/mikasa-chat-app)

## 🙏 Acknowledgments

- [React](https://reactjs.org/) - UI library
- [Tailwind CSS](https://tailwindcss.com/) - CSS framework
- [Supabase](https://supabase.com/) - Backend service
- [OpenAI](https://openai.com/) - AI API
- [Lucide](https://lucide.dev/) - Icon library