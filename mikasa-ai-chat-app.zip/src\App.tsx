import React from 'react';
import { useState, useEffect } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { useSupabaseAuth } from './hooks/useSupabaseAuth';
import LandingPage from './components/LandingPage';
import WelcomeLoginPage from './components/WelcomeLoginPage';
import ChatList from './components/ChatList';
import MobileChatView from './components/MobileChatView';
import ExplorePage from './components/ExplorePage';
import FeedPage from './components/FeedPage';
import NotificationsPage from './components/NotificationsPage';
import ProfilePage from './components/ProfilePage';
import SubscriptionPage from './components/SubscriptionPage';
import SupabaseLoginForm from './components/SupabaseLoginForm';
import { NavigationTab } from './types/navigation';

function App() {
  const { user, isLoggedIn, isLoading, isInitialized } = useSupabaseAuth();
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<NavigationTab>('chat');
  const [showWelcome, setShowWelcome] = useState(false);
  const [showLanding, setShowLanding] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [showSupabaseLogin, setShowSupabaseLogin] = useState(false);
  const [isDemoUser, setIsDemoUser] = useState(false);

  // Chrome-specific optimizations
  useEffect(() => {
    // Detect Chrome browser
    const isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
    
    if (isChrome) {
      // Add Chrome-specific class to body
      document.body.classList.add('chrome-browser');
      
      // Optimize for Chrome performance
      if ('requestIdleCallback' in window) {
        requestIdleCallback(() => {
          // Preload critical resources
          const link = document.createElement('link');
          link.rel = 'prefetch';
          link.href = '/src/components/ChatList.tsx';
          document.head.appendChild(link);
        });
      }
    }
    
    // Set viewport for mobile Chrome
    const viewport = document.querySelector('meta[name="viewport"]');
    if (viewport && window.innerWidth <= 768) {
      viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
    }
  }, []);

  const handleSelectChat = (chatId: string) => {
    setSelectedChat(chatId);
  };

  const handleBackToList = () => {
    setSelectedChat(null);
  };

  const handleNewChat = () => {
    // Create new chat logic here
    console.log('New chat');
  };

  const handleLoginSuccess = () => {
    setShowWelcome(false);
    setShowLanding(false);
    setShowRegister(false);
    setShowSupabaseLogin(false);
    setActiveTab('chat');
  };

  const handleGetStarted = () => {
    console.log('🔄 Get started clicked, showing welcome page');
    setShowLanding(false);
    setShowWelcome(false);
    setShowRegister(false);
    setShowSupabaseLogin(true);
  };

  const handleRegisterFromLanding = () => {
    console.log('🔄 Register clicked from landing, showing register page');
    setShowLanding(false);
    setShowWelcome(false);
    setShowRegister(true);
  };

  const handleDemoLoginFromLanding = () => {
    console.log('🔄 Demo login from landing, going to main app');
    setIsDemoUser(true);
    setShowLanding(false);
    setShowWelcome(false);
    setShowRegister(false);
    setShowSupabaseLogin(false);
    setActiveTab('chat');
  };

  // Handle logout - reset to landing page
  const handleLogout = () => {
    console.log('🔄 Logout clicked, resetting to landing');
    setIsDemoUser(false);
    setShowLanding(true);
    setShowWelcome(true);
    setShowRegister(false);
    setShowSupabaseLogin(false);
    setSelectedChat(null);
    setActiveTab('chat');
    // Clear demo user from localStorage
    localStorage.removeItem('mikasa_user');
  };

  // Listen for prompt events from explore page
  useEffect(() => {
    const handleSendPrompt = (event: CustomEvent) => {
      const { prompt, chatId } = event.detail;
      setSelectedChat(chatId);
      setActiveTab('chat');
      
      // Send the prompt after a short delay to ensure chat is loaded
      setTimeout(() => {
        const sendPromptEvent = new CustomEvent('autoSendMessage', { 
          detail: { message: prompt } 
        });
        window.dispatchEvent(sendPromptEvent);
      }, 200);
    };

    const handleNavigateToSubscription = () => {
      setActiveTab('subscription');
    };
    window.addEventListener('sendPromptToChat', handleSendPrompt as EventListener);
    window.addEventListener('navigateToSubscription', handleNavigateToSubscription as EventListener);
    
    return () => {
      window.removeEventListener('sendPromptToChat', handleSendPrompt as EventListener);
      window.removeEventListener('navigateToSubscription', handleNavigateToSubscription as EventListener);
    };
  }, []);

  // Initialize app state when auth is ready
  useEffect(() => {
    if (!isInitialized) {
      console.log('🔄 Auth not yet initialized, waiting...');
      return;
    }
    
    console.log('🔄 Auth initialized, setting up app state:', { isLoggedIn, isDemoUser });
    
    // Check for demo user in localStorage
    const savedUser = localStorage.getItem('mikasa_user');
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        if (userData.isDemo) {
          console.log('🔄 Demo user found, showing main app');
          setIsDemoUser(true);
          setShowWelcome(false);
          setShowLanding(false);
          setShowRegister(false);
          setShowSupabaseLogin(false);
          return;
        }
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('mikasa_user');
      }
    }
    
    if (isLoggedIn) {
      // If logged in via Supabase, show main app
      console.log('🔄 User logged in, showing main app');
      setShowWelcome(false);
      setShowLanding(false);
      setShowRegister(false);
      setShowSupabaseLogin(false);
    } else {
      // If not logged in, show landing page
      console.log('🔄 No user logged in, showing landing page');
      setShowLanding(true);
      setShowWelcome(false);
      setShowRegister(false);
      setShowSupabaseLogin(false);
    }
  }, [isInitialized, isLoggedIn]) // Remove isDemoUser from dependencies to prevent infinite loop

  // Persist demo user state
  useEffect(() => {
    if (isDemoUser) {
      // Save demo user state to localStorage
      const demoUser = {
        id: 'demo-user',
        name: 'Demo User',
        email: 'demo@mikasa.ai',
        avatar: '/dddddddddddd.jpg',
        isDemo: true
      };
      localStorage.setItem('mikasa_user', JSON.stringify(demoUser));
    }
  }, [isDemoUser]);

  // Show loading while checking auth status
  if (!isInitialized) {
    return (
      <div className="h-screen bg-gray-50 max-w-md mx-auto flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4 animate-pulse">
            👩‍💻
          </div>
          <p className="text-gray-600 mb-2">Memuat Mikasa AI...</p>
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
      </div>
    );
  }

  // Show landing page first
  if (showLanding && !isLoggedIn && !isDemoUser) {
    return (
      <div className="min-h-screen bg-gray-50">
        <LandingPage 
          onGetStarted={handleGetStarted} 
          onDemoLogin={handleDemoLoginFromLanding}
          onRegister={handleRegisterFromLanding}
        />
      </div>
    );
  }

  // Show register page
  if (showRegister && !isLoggedIn && !isDemoUser) {
    return (
      <div className="h-screen bg-gray-50 max-w-md mx-auto">
        <SupabaseLoginForm
          onBack={() => {
            setShowRegister(false);
            setShowLanding(true);
          }}
          onSuccess={handleLoginSuccess}
          defaultMode="signup"
        />
      </div>
    );
  }

  // Show Supabase login page
  if (showSupabaseLogin && !isLoggedIn && !isDemoUser) {
    return (
      <div className="h-screen bg-gray-50 max-w-md mx-auto">
        <SupabaseLoginForm
          onBack={() => {
            setShowSupabaseLogin(false);
            setShowLanding(true);
          }}
          onSuccess={handleLoginSuccess}
          defaultMode="signin"
        />
      </div>
    );
  }
  
  // Show welcome page only if not logged in AND showWelcome is true
  if (!isLoggedIn && !isDemoUser && showWelcome) {
    return (
      <div className="h-screen bg-gray-50 max-w-md mx-auto">
        <WelcomeLoginPage onLoginSuccess={handleLoginSuccess} />
      </div>
    );
  }

  // If not logged in and no special pages to show, show landing
  if (!isLoggedIn && !isDemoUser && !showWelcome && !showLanding && !showRegister && !showSupabaseLogin) {
    return (
      <div className="min-h-screen bg-gray-50">
        <LandingPage 
          onGetStarted={handleGetStarted} 
          onDemoLogin={handleDemoLoginFromLanding}
          onRegister={handleRegisterFromLanding}
        />
      </div>
    );
  }

  // If demo user or logged in, show main app
  if (!isLoggedIn && !isDemoUser) {
    return (
      <div className="min-h-screen bg-gray-50">
        <LandingPage 
          onGetStarted={handleGetStarted} 
          onDemoLogin={handleDemoLoginFromLanding}
          onRegister={handleRegisterFromLanding}
        />
      </div>
    );
  }

  // Main app content (shown when logged in or demo user)
  const renderContent = () => {
    if (selectedChat) {
      return (
        <MobileChatView 
          chatId={selectedChat} 
          onBack={handleBackToList}
          isDemoUser={isDemoUser}
        />
      );
    }

    switch (activeTab) {
      case 'chat':
        return (
          <ChatList 
            onSelectChat={handleSelectChat}
            onNewChat={handleNewChat}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            isDemoUser={isDemoUser}
          />
        );
      case 'explore':
        return <ExplorePage activeTab={activeTab} onTabChange={setActiveTab} isDemoUser={isDemoUser} />;
      case 'feed':
        return <FeedPage activeTab={activeTab} onTabChange={setActiveTab} isDemoUser={isDemoUser} />;
      case 'subscription':
        return <SubscriptionPage activeTab={activeTab} onTabChange={setActiveTab} isDemoUser={isDemoUser} />;
      case 'notifications':
        return <NotificationsPage activeTab={activeTab} onTabChange={setActiveTab} isDemoUser={isDemoUser} />;
      case 'profile':
        return <ProfilePage activeTab={activeTab} onTabChange={setActiveTab} onLogout={handleLogout} isDemoUser={isDemoUser} />;
      default:
        return (
          <ChatList 
            onSelectChat={handleSelectChat}
            onNewChat={handleNewChat}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            isDemoUser={isDemoUser}
          />
        );
    }
  };

  return (
    <ThemeProvider>
      <div className="h-screen bg-gray-50 dark:bg-gray-900 max-w-md mx-auto transition-colors duration-300">
        {renderContent()}
      </div>
    </ThemeProvider>
  );
}

export default App;