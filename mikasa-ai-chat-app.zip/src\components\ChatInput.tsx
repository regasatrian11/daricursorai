import React, { useState, KeyboardEvent } from 'react';
import { Send, Paperclip, Image, Camera } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation';
import CameraCapture from './CameraCapture';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  onSendImage: (file: File) => void;
  onTakePhoto: (file: File) => void;
  disabled: boolean;
}

export default function ChatInput({ onSendMessage, onSendImage, onTakePhoto, disabled }: ChatInputProps) {
  const { t } = useTranslation();
  const [input, setInput] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showCamera, setShowCamera] = useState(false);

  const handleSend = () => {
    if (input.trim() && !disabled) {
      onSendMessage(input.trim());
      setInput('');
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert('Ukuran file terlalu besar. Maksimal 10MB');
        return;
      }
      onSendImage(file);
      setShowAttachMenu(false);
    } else {
      alert('Silakan pilih file gambar yang valid');
    }
    // Reset input
    event.target.value = '';
  };

  const handleCameraCapture = (file: File) => {
    onTakePhoto(file);
    setShowAttachMenu(false);
    setShowCamera(false);
  };

  return (
    <>
      {showCamera && (
        <CameraCapture
          onCapture={handleCameraCapture}
          onClose={() => setShowCamera(false)}
        />
      )}
      
      <div className="p-4">
      {/* Attachment Menu */}
      {showAttachMenu && (
        <div className="mb-3 bg-white/90 backdrop-blur-md border border-white/30 rounded-2xl shadow-2xl p-4">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 rounded-2xl blur opacity-20"></div>
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-800">Pilih Media</h3>
              <button
                onClick={() => setShowAttachMenu(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
                title="Tutup"
              >
                ✕
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              {/* Upload from Gallery */}
              <label className="flex flex-col items-center gap-2 p-4 hover:bg-gray-50 rounded-xl cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 border border-gray-200 hover:border-blue-300">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-lg">
                  <Image size={20} className="text-white" />
                </div>
                <span className="text-xs text-gray-700 font-medium text-center">Dari Galeri</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={disabled}
                />
              </label>
              
              {/* Take Photo/Selfie */}
              <button
                onClick={() => {
                  setShowCamera(true);
                  setShowAttachMenu(false);
                }}
                disabled={disabled}
                className="flex flex-col items-center gap-2 p-4 hover:bg-gray-50 rounded-xl transition-all duration-300 hover:shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed border border-gray-200 hover:border-green-300"
              >
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                  <Camera size={20} className="text-white" />
                </div>
                <span className="text-xs text-gray-700 font-medium text-center">Ambil Foto</span>
              </button>
            </div>
            
            <div className="mt-3 text-xs text-gray-500 text-center">
              Maksimal 10MB per file
            </div>
          </div>
        </div>
      )}
      
      <div className="flex gap-3 items-end relative">
        <div className="absolute -inset-1 bg-gradient-to-r from-blue-400/20 via-purple-500/20 to-pink-500/20 rounded-3xl blur"></div>
        <div className="relative flex gap-3 items-end w-full bg-white/80 backdrop-blur-sm rounded-3xl p-3 border border-white/30 shadow-xl">
        <button
          onClick={() => setShowAttachMenu(!showAttachMenu)}
          disabled={disabled}
          className="w-11 h-11 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-600 rounded-full hover:from-gray-200 hover:to-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110"
          title="Lampirkan Media"
        >
          <Paperclip size={18} />
        </button>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={t('typeMessage')}
          disabled={disabled}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck="false"
          className="flex-1 resize-none rounded-2xl border border-white/30 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px] max-h-32 bg-white/70 backdrop-blur-sm shadow-inner font-medium"
          rows={1}
        />
        <button
          onClick={handleSend}
          disabled={disabled || !input.trim()}
          className="w-11 h-11 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110"
          title="Kirim Pesan"
        >
          <Send size={18} />
        </button>
        </div>
      </div>
      </div>
    </>
  );
}