import { useState, useEffect } from 'react';
import { Heart, MessageCircle, Share, Plus, Search, Bell, User, MessageCircle as ChatIcon, Crown, Trash2, MoreVertical } from 'lucide-react';
import { NavigationTab } from '../types/navigation';

interface FeedPageProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  isDemoUser?: boolean;
}

interface Post {
  id: string;
  author: string;
  authorAvatar: string;
  content: string;
  videoUrl?: string;
  imageUrl?: string;
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  timestamp: string;
  userId: string; // ID pengguna yang membuat postingan
  isOwnPost?: boolean; // Apakah ini postingan milik pengguna saat ini
}

export default function FeedPage({ activeTab, onTabChange, isDemoUser = false }: FeedPageProps) {
  // ID pengguna saat ini (untuk demo, kita gunakan 'current-user')
  const currentUserId = 'current-user';
  
  // Default posts
  const defaultPosts: Post[] = [
    {
      id: '1',
      author: 'Mikasa AI',
      authorAvatar: '/dddddddddddd.jpg',
      content: 'Halo semuanya! Ini adalah postingan pertama di feed Mikasa. Bagaimana kabar kalian hari ini? 😊',
      likes: 42,
      comments: 8,
      shares: 3,
      isLiked: false,
      timestamp: '2 jam yang lalu',
      userId: 'mikasa-ai',
      isOwnPost: false
    },
    {
      id: '2',
      author: 'Tech Enthusiast',
      authorAvatar: '/444444.jpg',
      content: 'Tips coding yang berguna: Selalu gunakan TypeScript untuk project yang lebih maintainable! 💻',
      likes: 28,
      comments: 5,
      shares: 2,
      isLiked: true,
      timestamp: '4 jam yang lalu',
      userId: 'tech-enthusiast',
      isOwnPost: false
    },
    {
      id: '3',
      author: 'AI Lover',
      authorAvatar: '/dddddddddddd.jpg',
      content: 'AI akan mengubah dunia dalam 5 tahun ke depan. Siap atau tidak, perubahan akan datang! 🤖',
      likes: 67,
      comments: 12,
      shares: 7,
      isLiked: false,
      timestamp: '6 jam yang lalu',
      userId: 'ai-lover',
      isOwnPost: false
    }
  ];

  const [posts, setPosts] = useState<Post[]>(defaultPosts);
  const [newPost, setNewPost] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  // Load posts from localStorage on component mount
  useEffect(() => {
    const savedPosts = localStorage.getItem('mikasa_feed_posts');
    if (savedPosts) {
      try {
        const parsedPosts = JSON.parse(savedPosts);
        setPosts(parsedPosts);
      } catch (error) {
        console.error('Error loading posts from localStorage:', error);
        setPosts(defaultPosts);
      }
    }
  }, []);

  // Save posts to localStorage whenever posts change
  useEffect(() => {
    localStorage.setItem('mikasa_feed_posts', JSON.stringify(posts));
  }, [posts]);

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            isLiked: !post.isLiked,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1
          }
        : post
    ));
  };

  const handleShare = (postId: string) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, shares: post.shares + 1 }
        : post
    ));
    alert('Postingan berhasil dibagikan!');
  };

  const handleCreatePost = () => {
    if (!newPost.trim()) return;
    
    const now = new Date();
    const post: Post = {
      id: `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, // More unique ID
      author: 'Anda',
      authorAvatar: '/dddddddddddd.jpg',
      content: newPost,
      likes: 0,
      comments: 0,
      shares: 0,
      isLiked: false,
      timestamp: 'Baru saja',
      userId: currentUserId,
      isOwnPost: true
    };
    
    setPosts(prev => [post, ...prev]);
    setNewPost('');
    
    // Show success message
    setShowSuccessMessage(true);
    setTimeout(() => {
      setShowSuccessMessage(false);
    }, 3000);
    
    console.log('Postingan berhasil dibuat:', post);
  };

  const handleDeletePost = (postId: string) => {
    setPosts(prev => prev.filter(post => post.id !== postId));
    setShowDeleteConfirm(null);
  };

  const handleProfileClick = (userId: string, authorName: string) => {
    // Navigate to profile or show profile modal
    alert(`Melihat profil ${authorName}`);
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-700">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 p-4 shadow-sm dark:bg-gray-800/90 dark:border-gray-700/50">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Feed</h1>
          <div className="flex items-center gap-2">
            <button 
              className="p-2 hover:bg-white/50 rounded-full transition-all duration-300 dark:hover:bg-gray-700"
              title="Cari postingan"
            >
              <Search size={20} className="text-gray-600 dark:text-gray-400" />
            </button>
            <button 
              className="p-2 hover:bg-white/50 rounded-full transition-all duration-300 dark:hover:bg-gray-700"
              title="Notifikasi"
            >
              <Bell size={20} className="text-gray-600 dark:text-gray-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Create Post */}
      <div className="bg-white/90 backdrop-blur-sm mx-4 mt-4 p-4 rounded-xl border border-white/20 shadow-lg dark:bg-gray-800/90 dark:border-gray-700/50">
        <div className="flex gap-3">
          <button
            onClick={() => handleProfileClick(currentUserId, 'Anda')}
            className="w-10 h-10 rounded-full overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all duration-300 focus:outline-none"
            title="Klik untuk melihat profil"
          >
            <img 
              src="/dddddddddddd.jpg" 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </button>
          <div className="flex-1">
            <textarea
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="Apa yang ingin Anda bagikan?"
              className="w-full p-3 border border-gray-200 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              rows={3}
            />
            <div className="flex justify-between items-center mt-3">
              <div className="flex gap-2">
                <button 
                  className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-all duration-300 dark:hover:bg-gray-700 dark:text-gray-400"
                  title="Tambah media"
                >
                  <Plus size={16} />
                </button>
              </div>
              <button
                onClick={handleCreatePost}
                disabled={!newPost.trim()}
                className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg font-medium hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Posting
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {posts.map((post) => (
          <div key={post.id} className="bg-white/90 backdrop-blur-sm rounded-xl p-4 border border-white/20 shadow-lg hover:shadow-xl transition-all duration-300 dark:bg-gray-800/90 dark:border-gray-700/50">
            {/* Post Header */}
            <div className="flex items-center gap-3 mb-3">
              <button
                onClick={() => handleProfileClick(post.userId, post.author)}
                className="w-10 h-10 rounded-full overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all duration-300 focus:outline-none"
                title={`Klik untuk melihat profil ${post.author}`}
              >
                <img 
                  src={post.authorAvatar} 
                  alt={post.author}
                  className="w-full h-full object-cover"
                />
              </button>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 dark:text-white">{post.author}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{post.timestamp}</p>
              </div>
              {post.isOwnPost && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowDeleteConfirm(post.id)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-all duration-300 dark:hover:bg-red-900/20"
                    title="Hapus postingan"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              )}
            </div>

            {/* Post Content */}
            <div className="mb-4">
              <p className="text-gray-800 leading-relaxed dark:text-gray-200">{post.content}</p>
            </div>

            {/* Post Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-6">
                <button
                  onClick={() => handleLike(post.id)}
                  className={`flex items-center gap-2 p-2 rounded-lg transition-all duration-300 ${
                    post.isLiked 
                      ? 'text-red-500 bg-red-50 dark:bg-red-900/20' 
                      : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700 dark:text-gray-400'
                  }`}
                >
                  <Heart size={18} className={post.isLiked ? 'fill-current' : ''} />
                  <span className="text-sm font-medium">{post.likes}</span>
                </button>
                
                <button className="flex items-center gap-2 p-2 text-gray-500 hover:bg-gray-50 rounded-lg transition-all duration-300 dark:hover:bg-gray-700 dark:text-gray-400">
                  <MessageCircle size={18} />
                  <span className="text-sm font-medium">{post.comments}</span>
                </button>
                
                <button
                  onClick={() => handleShare(post.id)}
                  className="flex items-center gap-2 p-2 text-gray-500 hover:bg-gray-50 rounded-lg transition-all duration-300 dark:hover:bg-gray-700 dark:text-gray-400"
                >
                  <Share size={18} />
                  <span className="text-sm font-medium">{post.shares}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Navigation */}
      <div className="flex items-center justify-around p-4 border-t border-white/20 bg-white/90 backdrop-blur-sm shadow-lg dark:bg-gray-800/90 dark:border-gray-700/50">
        <button
          onClick={() => onTabChange('chat')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group dark:hover:bg-gray-700"
        >
          {activeTab === 'chat' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <ChatIcon size={20} className={activeTab === 'chat' ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'} />
            <span className={`text-xs ${activeTab === 'chat' ? 'text-gray-900 font-medium dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
              Obrolan
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('explore')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group dark:hover:bg-gray-700"
        >
          {activeTab === 'explore' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-green-400 to-teal-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Search size={20} className={activeTab === 'explore' ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'} />
            <span className={`text-xs ${activeTab === 'explore' ? 'text-gray-900 font-medium dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
              Jelajahi
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('feed')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group dark:hover:bg-gray-700"
        >
          {activeTab === 'feed' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-orange-400 to-red-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Plus size={20} className={activeTab === 'feed' ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'} />
            <span className={`text-xs ${activeTab === 'feed' ? 'text-gray-900 font-medium dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
              Feed
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('notifications')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group dark:hover:bg-gray-700 min-w-0"
        >
          {activeTab === 'notifications' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-red-400 to-pink-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Bell size={20} className={activeTab === 'notifications' ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'} />
            <span className={`text-xs ${activeTab === 'notifications' ? 'text-gray-900 font-medium dark:text-white' : 'text-gray-400 dark:text-gray-500'} whitespace-nowrap`}>
              Pemberitahuan
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('profile')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group dark:hover:bg-gray-700"
        >
          {activeTab === 'profile' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-400 to-purple-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <User size={20} className={activeTab === 'profile' ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'} />
            <span className={`text-xs ${activeTab === 'profile' ? 'text-gray-900 font-medium dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
              Profil
            </span>
          </div>
        </button>
      </div>

      {/* Success Message */}
      {showSuccessMessage && (
        <div className="fixed top-4 right-4 z-50 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 animate-slide-in">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center">
              ✓
            </div>
            <span className="font-medium">Postingan berhasil dibuat!</span>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-sm w-full shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center">
                <Trash2 size={20} className="text-red-500" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Hapus Postingan</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Tindakan ini tidak dapat dibatalkan</p>
              </div>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Apakah Anda yakin ingin menghapus postingan ini? Postingan akan dihapus secara permanen.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="flex-1 px-4 py-2 text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-300"
              >
                Batal
              </button>
              <button
                onClick={() => handleDeletePost(showDeleteConfirm)}
                className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-300"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
