import React, { useState, useEffect, useRef } from 'react';
import { User, Settings, LogOut, Shield, Bell, HelpCircle, MessageCircle, Search, Crown, ChevronRight, Clock, Smartphone, BarChart3, UserCog, Mail, Plus, X, Info, Camera, Image, Upload } from 'lucide-react';
import { NavigationTab } from '../types/navigation';
import { useSupabaseAuth } from '../hooks/useSupabaseAuth';
import { useSubscription } from '../hooks/useSubscription';
import { DemoAuthService } from '../services/demoAuth';
import { adminAuth } from '../services/adminAuth';
import WelcomeLoginPage from './WelcomeLoginPage';
import PrivacySecurityPage from './PrivacySecurityPage';
import SettingsPage from './SettingsPage';
import HelpSupportPage from './HelpSupportPage';
import UserAnalyticsDashboard from './UserAnalyticsDashboard';
import AdminLoginPage from './AdminLoginPage';
import AdminDashboard from './AdminDashboard';

interface ProfilePageProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onLogout?: () => void;
  isDemoUser?: boolean;
}

export default function ProfilePage({ activeTab, onTabChange, onLogout, isDemoUser = false }: ProfilePageProps) {
  const { user, isLoggedIn, isInitialized, signOut } = useSupabaseAuth();
  
  // Determine if user is demo user
  const isActuallyDemoUser = isDemoUser || user?.isDemo || (user && user.id === 'demo-user');
  console.log('ProfilePage - isDemoUser prop:', isDemoUser);
  console.log('ProfilePage - user:', user);
  console.log('ProfilePage - isActuallyDemoUser:', isActuallyDemoUser);
  const { 
    subscription, 
    isPremium, 
    isPro, 
    isFree, 
    messagesUsed, 
    messagesLimit, 
    messagesRemaining,
    canSendMessage 
  } = useSubscription();
  const [showLoginPage, setShowLoginPage] = useState(false);
  const [showPrivacyPage, setShowPrivacyPage] = useState(false);
  const [showSettingsPage, setShowSettingsPage] = useState(false);
  const [showHelpPage, setShowHelpPage] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [showRegisterForm, setShowRegisterForm] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || 'Demo User',
    email: user?.email || 'demo@mikasa.ai',
    avatar: user?.avatar || '👤',
    profileImage: user?.profileImage || null
  });
  const [showImageOptions, setShowImageOptions] = useState(false);
  const imageOptionsRef = useRef<HTMLDivElement>(null);
  const [currentUser, setCurrentUser] = useState(() => {
    // Initialize with user data or demo data
    if (user) {
      return user;
    }
    // For demo users, get from localStorage
    const savedUser = localStorage.getItem('mikasa_user');
    if (savedUser) {
      try {
        return JSON.parse(savedUser);
      } catch (error) {
        console.error('Error parsing saved user:', error);
      }
    }
    return null;
  });
  const [showSuccessNotification, setShowSuccessNotification] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const demoAuth = DemoAuthService.getInstance();
  const demoInfo = demoAuth.getDemoInfo();
  const remainingTime = demoAuth.getFormattedRemainingTime();
  const adminSession = adminAuth.getAdminSession();

  // Update currentUser when user changes
  useEffect(() => {
    setCurrentUser(user);
  }, [user]);

  // Load user data from localStorage on mount for demo users
  useEffect(() => {
    if (isActuallyDemoUser && !user) {
      const savedUser = localStorage.getItem('mikasa_user');
      if (savedUser) {
        try {
          const parsedUser = JSON.parse(savedUser);
          setCurrentUser(parsedUser);
        } catch (error) {
          console.error('Error parsing saved user:', error);
        }
      }
    }
  }, [isActuallyDemoUser, user]);

  // Handle click outside to close image options
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (imageOptionsRef.current && !imageOptionsRef.current.contains(event.target as Node)) {
        setShowImageOptions(false);
      }
    };

    if (showImageOptions) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showImageOptions]);

  const handleNavigateToSubscription = () => {
    setShowPrivacyPage(false);
    onTabChange('subscription');
  };

  // Show loading while checking auth status
  if (!isInitialized) {
    return (
      <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4 animate-pulse shadow-2xl">
              👤
            </div>
            <p className="text-gray-600">Memuat...</p>
          </div>
        </div>
      </div>
    );
  }

  // Show login page if not logged in and not demo user
  if (!isLoggedIn && !isDemoUser) {
    if (showLoginForm) {
      return (
        <WelcomeLoginPage
          onLoginSuccess={() => {
            setShowLoginForm(false);
          }}
        />
      );
    }


    return (
      <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute top-40 right-16 w-24 h-24 bg-gradient-to-br from-pink-400/20 to-red-500/20 rounded-full blur-lg animate-pulse delay-1000"></div>
          <div className="absolute bottom-32 left-20 w-40 h-40 bg-gradient-to-br from-green-400/20 to-teal-500/20 rounded-full blur-2xl animate-pulse delay-2000"></div>
        </div>

        {/* Header */}
        <div className="relative z-10 bg-white/80 backdrop-blur-md border-b border-white/20 p-4 shadow-lg">
          <h1 className="text-xl font-semibold text-gray-900">Profil</h1>
        </div>

        <div className="flex-1 flex items-center justify-center p-4">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-3xl mx-auto mb-6 shadow-2xl animate-pulse">
              👤
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Login Diperlukan</h2>
            <p className="text-gray-600 text-sm mb-6">
              Silakan login terlebih dahulu untuk mengakses profil Anda
            </p>
            
            {/* Login/Register Menu */}
            <div className="w-full max-w-sm space-y-4">
              {/* Username/Password Login */}
              <div className="relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-2xl blur opacity-30"></div>
              <button
                onClick={() => setShowLoginForm(true)}
                className="relative w-full flex items-center justify-center gap-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-2xl py-4 px-6 hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 shadow-xl font-bold transform hover:scale-105"
              >
                <User size={20} />
                <div className="text-center">
                  <div className="font-semibold">Login dengan Username</div>
                  <div className="text-xs opacity-90">Masuk dengan username dan password</div>
                </div>
              </button>
              </div>
              
              {/* Email Login */}
              <div className="relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-400 to-purple-500 rounded-2xl blur opacity-30"></div>
              <button
                onClick={() => setShowLoginForm(true)}
                className="relative w-full flex items-center justify-center gap-3 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-2xl py-4 px-6 hover:from-indigo-600 hover:to-purple-600 transition-all duration-300 shadow-xl font-bold transform hover:scale-105"
              >
                <Mail size={20} />
                <div className="text-center">
                  <div className="font-semibold">Login dengan Email</div>
                  <div className="text-xs opacity-90">Login dengan Email dan Password</div>
                </div>
              </button>
              </div>
              
              <div className="relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-green-400 to-emerald-500 rounded-2xl blur opacity-30"></div>
              <button
                onClick={() => setShowLoginForm(true)}
                className="relative w-full flex items-center justify-center gap-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl py-4 px-6 hover:from-green-600 hover:to-emerald-600 transition-all duration-300 shadow-xl font-bold transform hover:scale-105"
              >
                <User size={20} />
                <span>Daftar Pengguna Baru</span>
              </button>
              </div>
              
              {/* Demo Login */}
              <div className="relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-400 to-pink-500 rounded-2xl blur opacity-30"></div>
              <button
                onClick={async () => {
                  try {
                    // Create demo user directly
                    const demoUser = {
                      id: 'demo_user_' + Date.now(),
                      name: 'Demo User',
                      email: 'demo@mikasa.ai',
                      avatar: '👤',
                      isDemo: true
                    };
                    
                    // Save demo user to localStorage
                    localStorage.setItem('mikasa_user', JSON.stringify(demoUser));
                    
                    // Track demo login
                    const { userAnalytics } = await import('../services/userAnalytics');
                    userAnalytics.trackUserLogin(demoUser.id, demoUser.email, 'demo');
                    
                    // Trigger re-render by calling parent
                    window.location.reload();
                  } catch (error) {
                    console.error('Demo login failed:', error);
                    alert('Login demo gagal. Silakan coba lagi.');
                  }
                }}
                className="relative w-full flex items-center justify-center gap-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl py-4 px-6 hover:from-purple-600 hover:to-pink-600 transition-all duration-300 shadow-xl font-bold transform hover:scale-105"
              >
                <User size={20} />
                <span>Coba Demo Gratis</span>
              </button>
              </div>
            </div>
            
            {/* Features Preview */}
            <div className="mt-8 text-center">
              <p className="text-sm text-gray-600 mb-4 font-medium">Fitur Unggulan:</p>
              <div className="flex justify-center gap-6 text-xs text-gray-500">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full flex items-center justify-center mb-2 shadow-lg">
                    💬
                  </div>
                  <span className="font-medium">Chat AI</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mb-2 shadow-lg">
                    🚀
                  </div>
                  <span className="font-medium">Cepat</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center mb-2 shadow-lg">
                    🔒
                  </div>
                  <span className="font-medium">Aman</span>
                </div>
              </div>
            </div>
            
            {/* Terms */}
            <div className="mt-6 text-center">
              <p className="text-xs text-gray-500 leading-relaxed max-w-xs mx-auto">
                Dengan menggunakan aplikasi ini, Anda menyetujui syarat dan ketentuan kami
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="relative z-10 flex items-center justify-around p-4 border-t border-white/20 bg-white/90 backdrop-blur-md shadow-2xl">
          <button 
            className="flex flex-col items-center gap-1 opacity-50 cursor-not-allowed"
          >
            <MessageCircle size={20} className="text-gray-300" />
            <span className="text-xs text-gray-300">Obrolan</span>
          </button>
          <button 
            className="flex flex-col items-center gap-1 opacity-50 cursor-not-allowed"
          >
            <Search size={20} className="text-gray-300" />
            <span className="text-xs text-gray-300">Jelajahi</span>
          </button>
          <button 
            className="flex flex-col items-center gap-1 opacity-50 cursor-not-allowed"
          >
            <Crown size={20} className="text-gray-300" />
            <span className="text-xs text-gray-300">Langganan</span>
          </button>
          <button 
            className="flex flex-col items-center gap-1 opacity-50 cursor-not-allowed"
          >
            <Bell size={20} className="text-gray-300" />
            <span className="text-xs text-gray-300">Pemberitahuan</span>
          </button>
          <button 
            onClick={() => onTabChange('profile')}
            className="flex flex-col items-center gap-1 relative group"
          >
            {activeTab === 'profile' && (
              <div className="absolute -inset-2 bg-gradient-to-r from-indigo-400 to-purple-500 rounded-xl blur opacity-50"></div>
            )}
            <div className="relative">
            <User size={20} className={activeTab === 'profile' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'profile' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Profil
            </span>
            </div>
          </button>
        </div>
      </div>
    );
  }

  // Show settings/privacy page if logged in
  if (showSettingsPage) {
    return (
      <SettingsPage 
        onBack={() => setShowSettingsPage(false)}
      />
    );
  }

  if (showHelpPage) {
    return (
      <HelpSupportPage 
        onBack={() => setShowHelpPage(false)}
      />
    );
  }

  if (showAnalytics) {
    return (
      <UserAnalyticsDashboard 
        onBack={() => setShowAnalytics(false)}
      />
    );
  }

  if (showAdminLogin) {
    return (
      <AdminLoginPage 
        onBack={() => setShowAdminLogin(false)}
        onLoginSuccess={() => {
          setShowAdminLogin(false);
          setShowAdminDashboard(true);
        }}
      />
    );
  }

  if (showAdminDashboard) {
    return (
      <AdminDashboard 
        onBack={() => setShowAdminDashboard(false)}
      />
    );
  }

  if (showPrivacyPage) {
    return (
      <PrivacySecurityPage 
        onBack={() => setShowPrivacyPage(false)}
        onNavigateToSubscription={handleNavigateToSubscription}
      />
    );
  }

  const handleLogout = () => {
    if (confirm('Apakah Anda yakin ingin keluar?')) {
      signOut();
      // Reset demo auth when logging out
      demoAuth.resetDemoAuth();
      // Call parent logout handler to reset app state
      if (onLogout) {
        onLogout();
      }
    }
  };

  const handleSettingsClick = () => {
    setShowSettingsPage(true);
  };

  const handlePrivacyClick = () => {
    setShowPrivacyPage(true);
  };

  const handleNotificationClick = () => {
    onTabChange('notifications');
  };

  const handleHelpClick = () => {
    setShowHelpPage(true);
  };

  const handleAnalyticsClick = () => {
    setShowAnalytics(true);
  };

  const handleAdminClick = () => {
    const session = adminAuth.getAdminSession();
    if (session) {
      setShowAdminDashboard(true);
    } else {
      setShowAdminLogin(true);
    }
  };

  const handleEditProfile = () => {
    setEditForm({
      name: currentUser?.name || 'Demo User',
      email: currentUser?.email || 'demo@mikasa.ai',
      avatar: currentUser?.avatar || '👤',
      profileImage: currentUser?.profileImage || null
    });
    setShowEditProfile(true);
  };

  const handleSaveProfile = () => {
    // For demo users, just update the local state
    if (isActuallyDemoUser) {
      // Create updated user object
      const updatedUser = {
        id: 'demo-user',
        name: editForm.name,
        email: editForm.email,
        avatar: editForm.avatar,
        profileImage: editForm.profileImage,
        isDemo: true
      };
      
      // Save to localStorage
      localStorage.setItem('mikasa_user', JSON.stringify(updatedUser));
      
      // Update the currentUser state directly
      setCurrentUser(updatedUser);
      console.log('Profile updated:', updatedUser);
      
      // Show success notification with specific message
      const hasImageChanged = editForm.profileImage !== (currentUser?.profileImage || null);
      const hasNameChanged = editForm.name !== (currentUser?.name || 'Demo User');
      const hasEmailChanged = editForm.email !== (currentUser?.email || 'demo@mikasa.ai');
      
      let message = 'Profil berhasil diperbarui!';
      if (hasImageChanged) {
        message = 'Foto profil berhasil diperbarui!';
      } else if (hasNameChanged || hasEmailChanged) {
        message = 'Informasi profil berhasil diperbarui!';
      }
      
      // Show notification
      console.log('Showing notification:', message);
      setSuccessMessage(message);
      setShowSuccessNotification(true);
      
      // Auto hide after 3 seconds
      setTimeout(() => {
        console.log('Hiding notification');
        setShowSuccessNotification(false);
      }, 3000);
      
      setShowEditProfile(false);
      return;
    }

    // For real users, you would update the database here
    // For now, just show a message
    alert('Fitur update profil untuk pengguna reguler akan segera hadir!');
    setShowEditProfile(false);
  };

  const handleCancelEdit = () => {
    setShowEditProfile(false);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert('Silakan pilih file gambar yang valid');
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('Ukuran file terlalu besar. Maksimal 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setEditForm({ ...editForm, profileImage: result, avatar: '' });
        setShowImageOptions(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraCapture = () => {
    // Create a file input for camera
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment'; // Use back camera if available
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          setEditForm({ ...editForm, profileImage: result, avatar: '' });
          setShowImageOptions(false);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleRemoveImage = () => {
    setEditForm({ ...editForm, profileImage: null, avatar: '👤' });
    setShowImageOptions(false);
  };

  // Function removed - now handled directly in handleSaveProfile

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-16 w-24 h-24 bg-gradient-to-br from-pink-400/20 to-red-500/20 rounded-full blur-lg animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-20 w-40 h-40 bg-gradient-to-br from-green-400/20 to-teal-500/20 rounded-full blur-2xl animate-pulse delay-2000"></div>
      </div>

      {/* Header */}
      <div className="relative z-10 bg-white/80 backdrop-blur-md border-b border-white/20 p-4 shadow-lg">
        <h1 className="text-xl font-semibold text-gray-900">Profil</h1>
      </div>

      {/* Profile Section */}
      <div className="relative z-10 bg-white/90 backdrop-blur-md mx-4 mt-4 rounded-2xl border border-white/30 p-6 shadow-2xl">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 rounded-2xl blur opacity-20"></div>
        <div className="relative">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl relative shadow-2xl overflow-hidden">
            {currentUser?.profileImage ? (
              <img 
                src={currentUser.profileImage} 
                alt="Profile" 
                className="w-full h-full object-cover rounded-full"
              />
            ) : (
              currentUser?.avatar || '👤'
            )}
            {isActuallyDemoUser && (
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-xs text-white font-bold">D</span>
              </div>
            )}
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-gray-900">{currentUser?.name || 'Demo User'}</h2>
            <p className="text-gray-600 text-sm font-medium">{currentUser?.email || 'demo@mikasa.ai'}</p>
            {isActuallyDemoUser && (
              <div className="flex items-center gap-1 mt-1">
                <Smartphone size={12} className="text-blue-500" />
                <span className="text-xs text-blue-600 font-medium">Akun Demo</span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={handleEditProfile}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-white/70 rounded-full transition-all duration-300 hover:shadow-lg hover:scale-110"
              title="Edit Profil"
            >
              <UserCog size={16} />
            </button>
            {!isActuallyDemoUser && (
              <button 
                onClick={handleSettingsClick}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-white/70 rounded-full transition-all duration-300 hover:shadow-lg hover:scale-110"
                title="Pengaturan"
              >
                <Settings size={16} />
              </button>
            )}
          </div>
        </div>
        </div>
      </div>

        {/* Demo Restrictions Info */}
        {isActuallyDemoUser && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock size={16} className="text-blue-600" />
              <span className="text-sm font-medium text-blue-900">Status Demo</span>
            </div>
            <p className="text-xs text-blue-700 mb-2">
              Sisa waktu: {remainingTime}
            </p>
            <div className="bg-yellow-50 border border-yellow-200 rounded p-2">
              <p className="text-xs text-yellow-700 font-medium mb-1">Pembatasan Akun Demo:</p>
              <ul className="text-xs text-yellow-600 space-y-1">
                <li>• Tidak dapat mengedit profil</li>
                <li>• Tidak dapat mengubah foto profil</li>
                <li>• Batas 10 pesan per hari</li>
                <li>• Akses terbatas selama 24 jam</li>
                <li>• Tidak dapat berlangganan paket premium</li>
                <li>• Tidak dapat melakukan pembayaran</li>
              </ul>
              <div className="mt-2 pt-2 border-t border-yellow-300">
                <p className="text-xs text-yellow-800 font-medium">
                  💡 Daftar akun reguler untuk akses penuh
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Usage Stats */}
        <div className="bg-gradient-to-br from-gray-50/80 to-white/80 backdrop-blur-sm rounded-2xl p-4 border border-white/30 shadow-inner">
          <h3 className="font-medium text-gray-900 mb-3">Statistik Penggunaan</h3>
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-600">Status Langganan</span>
              <div className="flex items-center gap-2">
                {subscription?.end_date && (
                  <span className="text-xs text-gray-500">Berakhir: {new Date(subscription.end_date).toLocaleDateString('id-ID')}</span>
                )}
              <span className={`text-sm font-bold px-3 py-1 rounded-full shadow-lg ${
                isPremium ? 'bg-purple-100 text-purple-800' :
                isPro ? 'bg-orange-100 text-orange-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {isPremium ? 'Premium' : isPro ? 'Pro' : user?.isDemo ? 'Demo' : 'Gratis'}
              </span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">{messagesUsed}</p>
              <p className="text-xs text-gray-600">Pesan Terkirim</p>
            </div>
            <div>
              <p className="text-3xl font-bold bg-gradient-to-r from-gray-600 to-gray-800 bg-clip-text text-transparent">
                {messagesLimit === -1 ? '∞' : messagesLimit}
              </p>
              <p className="text-xs text-gray-600">
                Batas Pesan
              </p>
            </div>
          </div>
          <div className="mt-3 bg-gray-200 rounded-full h-3 shadow-inner">
            <div 
              className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 h-3 rounded-full transition-all duration-500 shadow-lg"
              style={{ 
                width: messagesLimit === -1 ? '100%' : `${Math.min((messagesUsed / messagesLimit) * 100, 100)}%` 
              } as React.CSSProperties}
            ></div>
          </div>
          {!canSendMessage && messagesLimit !== -1 && (
            <div className="mt-3 p-3 bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 rounded-xl">
              <p className="text-xs text-red-700 font-medium text-center">
              ⚠️ Batas harian tercapai! Upgrade untuk melanjutkan chat.
              </p>
            </div>
          )}
        </div>


      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        <button
          onClick={handleSettingsClick}
          className="w-full bg-white/90 backdrop-blur-sm rounded-2xl border border-white/30 p-4 flex items-center gap-3 hover:bg-white/70 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105 relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400/0 to-purple-500/0 group-hover:from-blue-400/20 group-hover:to-purple-500/20 rounded-2xl blur transition-all duration-300"></div>
          <div className="relative flex items-center gap-3 w-full">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
            <Settings size={18} className="text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-bold text-gray-900">
              Pengaturan
            </h3>
            <p className="text-sm text-gray-600 font-medium">
              Kelola preferensi aplikasi
            </p>
          </div>
          <ChevronRight size={16} className="text-purple-500" />
          </div>
        </button>

        <button
          onClick={handlePrivacyClick}
          className="w-full bg-white/90 backdrop-blur-sm rounded-2xl border border-white/30 p-4 flex items-center gap-3 hover:bg-white/70 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105 relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-green-400/0 to-teal-500/0 group-hover:from-green-400/20 group-hover:to-teal-500/20 rounded-2xl blur transition-all duration-300"></div>
          <div className="relative flex items-center gap-3 w-full">
          <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-full flex items-center justify-center shadow-lg">
            <Shield size={18} className="text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-bold text-gray-900">
              Privasi & Keamanan
            </h3>
            <p className="text-sm text-gray-600 font-medium">
              Kontrol data dan keamanan
            </p>
          </div>
          <ChevronRight size={16} className="text-teal-500" />
          </div>
        </button>

        <button
          onClick={handleNavigateToSubscription}
          className="w-full bg-white/90 backdrop-blur-sm rounded-2xl border border-white/30 p-4 flex items-center gap-3 hover:bg-white/70 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105 relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-400/0 to-orange-500/0 group-hover:from-yellow-400/20 group-hover:to-orange-500/20 rounded-2xl blur transition-all duration-300"></div>
          <div className="relative flex items-center gap-3 w-full">
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-full flex items-center justify-center shadow-lg">
            <Crown size={18} className="text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-bold text-gray-900">
              Langganan
            </h3>
            <p className="text-sm text-gray-600 font-medium">
              Kelola paket langganan Anda
            </p>
          </div>
          <ChevronRight size={16} className="text-orange-500" />
          </div>
        </button>

        <button
          onClick={handleNotificationClick}
          className="w-full bg-white/90 backdrop-blur-sm rounded-2xl border border-white/30 p-4 flex items-center gap-3 hover:bg-white/70 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105 relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-400/0 to-orange-500/0 group-hover:from-yellow-400/20 group-hover:to-orange-500/20 rounded-2xl blur transition-all duration-300"></div>
          <div className="relative flex items-center gap-3 w-full">
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-full flex items-center justify-center shadow-lg">
            <Bell size={18} className="text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-bold text-gray-900">
              Notifikasi
            </h3>
            <p className="text-sm text-gray-600 font-medium">
              Atur pemberitahuan
            </p>
          </div>
          <ChevronRight size={16} className="text-orange-500" />
          </div>
        </button>

        {/* Analytics Dashboard - Only for admin/demo users */}


        <button
          onClick={handleHelpClick}
          className="w-full bg-white/90 backdrop-blur-sm rounded-2xl border border-white/30 p-4 flex items-center gap-3 hover:bg-white/70 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105 relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-400/0 to-red-500/0 group-hover:from-pink-400/20 group-hover:to-red-500/20 rounded-2xl blur transition-all duration-300"></div>
          <div className="relative flex items-center gap-3 w-full">
          <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-red-600 rounded-full flex items-center justify-center shadow-lg">
            <HelpCircle size={18} className="text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-bold text-gray-900">
              Bantuan & Dukungan
            </h3>
            <p className="text-sm text-gray-600 font-medium">
              FAQ dan kontak support
            </p>
          </div>
          <ChevronRight size={16} className="text-red-500" />
          </div>
        </button>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          className="w-full bg-white/90 backdrop-blur-sm rounded-2xl border border-red-200/50 p-4 flex items-center gap-3 hover:bg-red-50/80 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-105 relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-red-400/0 to-pink-500/0 group-hover:from-red-400/20 group-hover:to-pink-500/20 rounded-2xl blur transition-all duration-300"></div>
          <div className="relative flex items-center gap-3 w-full">
          <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-600 rounded-full flex items-center justify-center shadow-lg">
            <LogOut size={18} className="text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-bold text-red-600">Keluar</h3>
            <p className="text-sm text-red-500 font-medium">Keluar dari akun Anda</p>
          </div>
          </div>
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="relative z-10 flex items-center justify-around p-4 border-t border-white/20 bg-white/90 backdrop-blur-md shadow-2xl">
        <button 
          onClick={() => onTabChange('chat')}
          className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/70 transition-all duration-300 hover:shadow-md hover:scale-105 relative group"
        >
          {activeTab === 'chat' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
          <MessageCircle size={20} className={activeTab === 'chat' ? 'text-gray-900' : 'text-gray-400'} />
          <span className={`text-xs ${activeTab === 'chat' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
            Obrolan
          </span>
          </div>
        </button>
        <button 
          onClick={() => onTabChange('explore')}
          className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/70 transition-all duration-300 hover:shadow-md hover:scale-105 relative group"
        >
          {activeTab === 'explore' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-green-400 to-teal-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
          <Search size={20} className={activeTab === 'explore' ? 'text-gray-900' : 'text-gray-400'} />
          <span className={`text-xs ${activeTab === 'explore' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
            Jelajahi
          </span>
          </div>
        </button>
        <button 
          onClick={() => onTabChange('feed')}
          className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/70 transition-all duration-300 hover:shadow-md hover:scale-105 relative group"
        >
          {activeTab === 'feed' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-orange-400 to-red-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Plus size={20} className={activeTab === 'feed' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'feed' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Feed
            </span>
          </div>
        </button>
        <button 
          onClick={() => onTabChange('notifications')}
          className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/70 transition-all duration-300 hover:shadow-md hover:scale-105 relative group min-w-0"
        >
          {activeTab === 'notifications' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-red-400 to-pink-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
          <Bell size={20} className={activeTab === 'notifications' ? 'text-gray-900' : 'text-gray-400'} />
          <span className={`text-xs ${activeTab === 'notifications' ? 'text-gray-900 font-medium' : 'text-gray-400'} whitespace-nowrap`}>
            Pemberitahuan
          </span>
          </div>
        </button>
        <button 
          onClick={() => onTabChange('profile')}
          className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/70 transition-all duration-300 hover:shadow-md hover:scale-105 relative group"
        >
          {activeTab === 'profile' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-400 to-purple-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
          <User size={20} className={activeTab === 'profile' ? 'text-gray-900' : 'text-gray-400'} />
          <span className={`text-xs ${activeTab === 'profile' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
            Profil
          </span>
          </div>
        </button>
      </div>

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Edit Profil</h2>
              <button
                onClick={handleCancelEdit}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                title="Tutup"
              >
                <X size={20} className="text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Avatar */}
              <div className="flex flex-col items-center">
                <div className="relative">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-3xl mb-4 shadow-lg overflow-hidden">
                    {editForm.profileImage ? (
                      <img 
                        src={editForm.profileImage} 
                        alt="Profile" 
                        className="w-full h-full object-cover rounded-full"
                      />
                    ) : (
                      editForm.avatar
                    )}
                  </div>
                  <button
                    onClick={() => setShowImageOptions(!showImageOptions)}
                    className="absolute -bottom-1 -right-1 w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-blue-600 transition-colors"
                    title="Ubah Foto Profil"
                  >
                    <Camera size={16} />
                  </button>
                </div>

                {/* Image Options Modal */}
                {showImageOptions && (
                  <div ref={imageOptionsRef} className="absolute top-0 left-0 right-0 bg-white rounded-lg shadow-xl border p-4 z-10">
                    <div className="flex flex-col gap-3">
                      <button
                        onClick={handleCameraCapture}
                        className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <Camera size={20} className="text-blue-500" />
                        <span className="text-sm font-medium">Ambil Foto</span>
                      </button>
                      <label className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
                        <Image size={20} className="text-green-500" />
                        <span className="text-sm font-medium">Pilih dari Galeri</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </label>
                      {editForm.profileImage && (
                        <button
                          onClick={handleRemoveImage}
                          className="flex items-center gap-3 p-3 hover:bg-red-50 rounded-lg transition-colors text-red-600"
                        >
                          <X size={20} />
                          <span className="text-sm font-medium">Hapus Foto</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* Emoji Options */}
                {!editForm.profileImage && (
                  <div className="flex gap-2 mt-2">
                    {['👤', '👨', '👩', '🧑', '👨‍💼', '👩‍💼', '🤵', '👰'].map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => setEditForm({ ...editForm, avatar: emoji, profileImage: null })}
                        className={`w-10 h-10 rounded-full flex items-center justify-center text-xl transition-all duration-300 ${
                          editForm.avatar === emoji 
                            ? 'bg-blue-500 text-white shadow-lg scale-110' 
                            : 'bg-gray-100 hover:bg-gray-200'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nama
                </label>
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Masukkan nama Anda"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Masukkan email Anda"
                />
              </div>

              {/* Demo User Notice */}
              {isActuallyDemoUser && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Info size={16} className="text-blue-600" />
                    <span className="text-sm text-blue-800">
                      Perubahan akan disimpan untuk sesi demo ini
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mt-6">
              <button
                onClick={handleCancelEdit}
                className="flex-1 py-3 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Batal
              </button>
              <button
                onClick={handleSaveProfile}
                className="flex-1 py-3 px-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all duration-300 font-medium"
              >
                Simpan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Notification */}
      {showSuccessNotification && (
        <div className="fixed top-4 right-4 z-50 animate-slide-in">
          <div className="bg-green-500 text-white px-6 py-4 rounded-lg shadow-2xl flex items-center gap-3 max-w-sm">
            <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <p className="font-semibold">Berhasil!</p>
              <p className="text-sm opacity-90">{successMessage}</p>
            </div>
            <button
              onClick={() => {
                console.log('Manual close notification');
                setShowSuccessNotification(false);
              }}
              className="ml-2 text-white/80 hover:text-white transition-colors"
              title="Tutup notifikasi"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}