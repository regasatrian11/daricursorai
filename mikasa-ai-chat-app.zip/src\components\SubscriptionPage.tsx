import { useState } from 'react';
import { Crown, Check, ArrowLeft, CreditCard, Calendar, Star, Zap, Shield, MessageCircle, Search, Plus, Bell, User } from 'lucide-react';
import { NavigationTab } from '../types/navigation';
import { useSupabaseAuth } from '../hooks/useSupabaseAuth';
import { useSubscription } from '../hooks/useSubscription';

interface SubscriptionPageProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  isDemoUser?: boolean;
}

export default function SubscriptionPage({ activeTab, onTabChange, isDemoUser = false }: SubscriptionPageProps) {
  const { isLoggedIn } = useSupabaseAuth();
  const { subscription, isPremium, isPro, isFree, messagesUsed, messagesLimit, messagesRemaining } = useSubscription();

  const plans = [
    {
      id: 'free',
      name: 'Gratis',
      price: 0,
      duration: 'Selamanya',
      features: [
        '10 pesan per hari',
        'Akses dasar',
        'Dukungan email',
        'Fitur standar'
      ],
      isPopular: false,
      isCurrent: isFree
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 50000,
      duration: 'per bulan',
      features: [
        '100 pesan per hari',
        'Fitur premium',
        'Dukungan prioritas',
        'Analitik lanjutan',
        'Tema eksklusif'
      ],
      isPopular: true,
      isCurrent: isPro
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 100000,
      duration: 'per bulan',
      features: [
        'Pesan tanpa batas',
        'Semua fitur',
        'Dukungan 24/7',
        'Analitik lengkap',
        'API access',
        'Tema premium'
      ],
      isPopular: false,
      isCurrent: isPremium
    }
  ];

  const handleSubscribe = (planId: string) => {
    if (planId === 'free') return;

    // Always require login for premium plans (demo users can't subscribe)
    if (!isLoggedIn && !isDemoUser) {
      alert('Silakan login terlebih dahulu untuk berlangganan paket premium');
      onTabChange('profile');
      return;
    }

    // Demo users can't subscribe to premium plans
    if (isDemoUser) {
      alert('Demo user tidak dapat berlangganan paket premium. Silakan daftar akun reguler terlebih dahulu.');
      return;
    }

    // Handle subscription logic here
    alert(`Berlangganan paket ${plans.find(p => p.id === planId)?.name} akan segera tersedia!`);
  };

  // Show login prompt if not logged in and not demo user
  if (!isLoggedIn && !isDemoUser) {
    return (
      <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onTabChange('profile')}
              className="p-2 hover:bg-white/50 rounded-full transition-all duration-300"
            >
              <ArrowLeft size={20} className="text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">Langganan</h1>
          </div>
        </div>

        {/* Login Prompt */}
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 border border-white/20 shadow-xl text-center max-w-md">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Crown size={32} className="text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Login Diperlukan</h2>
            <p className="text-gray-600 mb-6">
              Silakan login terlebih dahulu untuk melihat dan mengelola paket langganan Anda.
            </p>
            <button
              onClick={() => onTabChange('profile')}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-6 rounded-xl font-medium hover:shadow-lg transition-all duration-300"
            >
              Kembali ke Profil
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onTabChange('profile')}
            className="p-2 hover:bg-white/50 rounded-full transition-all duration-300"
          >
            <ArrowLeft size={20} className="text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Langganan</h1>
        </div>
      </div>

      {/* Current Status */}
      <div className="bg-white/90 backdrop-blur-sm mx-4 mt-4 p-4 rounded-xl border border-white/20 shadow-lg">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
            <Crown size={20} className="text-white" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Status Langganan</h3>
            <p className="text-sm text-gray-600">
              {isDemoUser ? 'Demo User' : 
               isPremium ? 'Premium' : 
               isPro ? 'Pro' : 'Gratis'}
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-2xl font-bold text-purple-600">{messagesUsed}</p>
            <p className="text-xs text-gray-600">Pesan Terkirim</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-600">
              {messagesLimit === -1 ? '∞' : messagesLimit}
            </p>
            <p className="text-xs text-gray-600">Batas Pesan</p>
          </div>
        </div>
      </div>

      {/* Plans */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <h2 className="text-lg font-bold text-gray-900 text-center mb-4">Pilih Paket Langganan</h2>
        
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`bg-white/90 backdrop-blur-sm rounded-xl border-2 p-4 shadow-lg hover:shadow-xl transition-all duration-300 ${
              plan.isPopular
                ? 'border-purple-500 relative'
                : 'border-white/20'
            }`}
          >
            {plan.isPopular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-3 py-1 rounded-full font-medium">
                  Paling Populer
                </span>
              </div>
            )}
            
            {plan.isCurrent && (
              <div className="absolute -top-2 -right-2">
                <div className="bg-green-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                  Aktif
                </div>
              </div>
            )}

            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
              <div className="text-right">
                <span className="text-3xl font-bold text-gray-900">
                  {plan.price === 0 ? 'Gratis' : `Rp ${plan.price.toLocaleString()}`}
                </span>
                {plan.price > 0 && (
                  <p className="text-sm text-gray-600">{plan.duration}</p>
                )}
              </div>
            </div>

            <ul className="space-y-2 mb-4">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-center gap-2">
                  <Check size={16} className="text-green-500 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => handleSubscribe(plan.id)}
              disabled={plan.isCurrent || (isDemoUser && plan.id !== 'free')}
              className={`w-full py-3 px-4 rounded-xl font-medium transition-all duration-300 ${
                plan.isCurrent
                  ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                  : plan.isPopular
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-lg'
                  : 'bg-gray-900 text-white hover:bg-gray-800'
              }`}
            >
              {plan.isCurrent ? 'Paket Aktif' : 
               isDemoUser && plan.id !== 'free' ? 'Demo User' : 
               plan.id === 'free' ? 'Gratis' : 'Berlangganan'}
            </button>
          </div>
        ))}
      </div>

      {/* Bottom Navigation */}
      <div className="flex items-center justify-around p-4 border-t border-white/20 bg-white/90 backdrop-blur-sm shadow-lg">
        <button
          onClick={() => onTabChange('chat')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group"
        >
          {activeTab === 'chat' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <MessageCircle size={20} className={activeTab === 'chat' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'chat' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Obrolan
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('explore')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group"
        >
          {activeTab === 'explore' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-green-400 to-teal-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Search size={20} className={activeTab === 'explore' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'explore' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Jelajahi
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('feed')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group"
        >
          {activeTab === 'feed' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-orange-400 to-red-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Plus size={20} className={activeTab === 'feed' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'feed' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Feed
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('notifications')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group"
        >
          {activeTab === 'notifications' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-red-400 to-pink-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <Bell size={20} className={activeTab === 'notifications' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'notifications' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Notifikasi
            </span>
          </div>
        </button>
        
        <button
          onClick={() => onTabChange('profile')}
          className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/50 transition-all duration-300 hover:shadow-lg hover:scale-105 relative group"
        >
          {activeTab === 'profile' && (
            <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-400 to-purple-500 rounded-lg blur opacity-30"></div>
          )}
          <div className="relative">
            <User size={20} className={activeTab === 'profile' ? 'text-gray-900' : 'text-gray-400'} />
            <span className={`text-xs ${activeTab === 'profile' ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
              Profil
            </span>
          </div>
        </button>
      </div>
    </div>
  );
}
