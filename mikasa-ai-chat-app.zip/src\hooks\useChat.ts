import { useState, useCallback, useRef, useEffect } from 'react';
import { Message, ChatState } from '../types/chat';
import { getChatCompletion } from '../services/openai';
import { useSupabaseAuth } from './useSupabaseAuth';
import { useSubscription } from './useSubscription';
import { userAnalytics } from '../services/userAnalytics';
import { getCharacterResponse } from '../services/characterResponses';

export function useChat(isDemoUser: boolean = false, chatId?: string) {
  const { isLoggedIn } = useSupabaseAuth();
  const { canSendMessage, messagesUsed, messagesLimit, messagesRemaining, updateUsage } = useSubscription();
  
  const [state, setState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    error: null,
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [state.messages, scrollToBottom]);

  const sendMessage = useCallback(async (content: string) => {
    // Check daily message limit (skip for demo users)
    if (!isDemoUser && !canSendMessage) {
      if (!isLoggedIn) {
        setState(prev => ({
          ...prev,
          error: 'Silakan login terlebih dahulu untuk dapat mengirim pesan.'
        }));
        return;
      }
      
      setState(prev => ({
        ...prev,
        error: `Anda telah mencapai batas ${messagesLimit} pesan per hari. ${messagesLimit === 10 ? 'Daftar akun reguler atau upgrade ke Premium untuk pesan tanpa batas!' : 'Upgrade ke Premium untuk pesan tanpa batas!'}`
      }));
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: 'user',
      timestamp: new Date(),
    };

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isLoading: true,
      error: null,
    }));

    try {
      let response: string;
      
      // Use character-specific responses if chatId is provided
      if (chatId && (isDemoUser || isLoggedIn)) {
        console.log('🔄 Getting character response...');
        response = getCharacterResponse(chatId, content);
        console.log('✅ Character response received');
      } else {
        const chatHistory = state.messages.map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

        console.log('🔄 Sending message to AI...');
        response = await getChatCompletion([
          ...chatHistory,
          { role: 'user', content }
        ]);
        console.log('✅ AI response received');
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date(),
      };

      // Update usage in Supabase
      await updateUsage();
      
      // Track message in analytics
      const savedUser = localStorage.getItem('mikasa_user'); // Keep for demo compatibility
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          userAnalytics.trackMessageSent(userData.id);
        } catch (error) {
          console.error('Error tracking message:', error);
        }
      }
      
      setState(prev => ({
        ...prev,
        messages: [...prev.messages, assistantMessage],
        isLoading: false,
      }));
    } catch (error: any) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: error.message,
      }));
    }
  }, [state.messages, canSendMessage, messagesLimit, updateUsage, isLoggedIn]);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  const clearChat = useCallback(() => {
    setState({
      messages: [],
      isLoading: false,
      error: null,
    });
  }, []);

  // Get current usage stats
  const getUsageStats = useCallback(() => {
    return {
      messagesUsed,
      messagesLimit,
      messagesRemaining,
      canSend: isLoggedIn || isDemoUser ? (isDemoUser ? true : canSendMessage) : false
    };
  }, [messagesUsed, messagesLimit, messagesRemaining, canSendMessage, isLoggedIn, isDemoUser]);
  
  return {
    messages: state.messages,
    isLoading: state.isLoading,
    error: state.error,
    sendMessage,
    clearError,
    clearChat,
    messagesEndRef,
    getUsageStats,
  };
}