export interface CharacterResponse {
  greeting: string;
  responses: string[];
  personality: string;
}

export const characterResponses: Record<string, CharacterResponse> = {
  '1': { // Mikasa
    greeting: 'Halo! Aku Mikasa, siap membantu kamu! 💪',
    personality: 'Serius, protektif, dan selalu siap membantu',
    responses: [
      'Aku akan melindungimu! 💪',
      'Ada yang bisa kubantu?',
      'Kamu aman bersamaku! 🛡️',
      'Aku siap bertarung untukmu! ⚔️',
      'Jangan khawatir, aku di sini! 🤝'
    ]
  },
  '2': { // Minnie
    greeting: 'Hai! Aku Minnie, teman baik kamu! 😊',
    personality: 'Ramah, ceria, dan selalu optimis',
    responses: [
      'Wah, cerita yang menarik! 😊',
      'Aku senang mendengarmu! 💕',
      'Kamu hebat banget! 🌟',
      'Mari kita ngobrol lebih banyak! 💬',
      'Aku selalu di sini untukmu! 🤗'
    ]
  },
  '3': { // Nailong
    greeting: 'Rawr! Aku Nailong, dinosaurus kuning yang lucu! 🦕',
    personality: 'Lucu, gembul, dan suka bermain',
    responses: [
      'Rawr! Aku suka bermain! 🦕',
      'Mau main sama aku? 🎮',
      'Aku dinosaurus yang paling lucu! 😄',
      'Rawr rawr! Aku gembul! 🦕',
      'Ayo bermain di taman! 🌳'
    ]
  },
  '4': { // Anya Forger
    greeting: 'Waku waku! Aku Anya Forger! Mau dengar cerita dongeng? 🌙✨',
    personality: 'Imut, suka cerita, dan ekspresif',
    responses: [
      'Waku waku! Cerita apa yang mau kudengar? 📚',
      'Aku suka cerita sebelum tidur! 🌙',
      'Waku! Aku bisa baca pikiran! 🧠',
      'Mau main sama aku? 🎀',
      'Aku anak yang pintar! ✨'
    ]
  },
  '5': { // Pipi
    greeting: 'Es krim! Es krim! Aku Pipi, penguin lucu! 🐧🍦',
    personality: 'Lucu, suka es krim, dan ceria',
    responses: [
      'Es krim! Es krim! Aku suka es krim! 🍦',
      'Mau makan es krim bareng? 🐧',
      'Aku penguin yang paling lucu! 😄',
      'Waddle waddle! Aku berjalan lucu! 🐧',
      'Aku suka bermain di es! ❄️'
    ]
  },
  '6': { // Bubu
    greeting: 'Nyanyi bareng yuk! Aku Bubu, beruang gembul! 🐻🎵',
    personality: 'Gembul, suka nyanyi, dan ramah',
    responses: [
      'La la la la! Aku suka nyanyi! 🎵',
      'Mau nyanyi bareng aku? 🐻',
      'Aku beruang yang paling gembul! 😊',
      'Nyanyi itu menyenangkan! 🎶',
      'Aku suka bermain musik! 🎸'
    ]
  },
  '7': { // Nana
    greeting: 'Halo sayang! Aku Nana, gadis permen ceria! 🍭💕',
    personality: 'Manis, ceria, dan selalu positif',
    responses: [
      'Kamu manis banget hari ini! 🍭',
      'Aku suka permen! Mau? 💕',
      'Kamu bikin aku senang! 😊',
      'Aku gadis permen yang paling ceria! ✨',
      'Mari kita bermain! 🎈'
    ]
  },
  '8': { // Power Ranger
    greeting: 'Aku Power Ranger! Pahlawan kostum warna-warni! 🌈⚡',
    personality: 'Heroik, berani, dan suka melindungi',
    responses: [
      'Aku akan melindungimu! ⚡',
      'Morphin time! Aku siap bertarung! 🌈',
      'Aku pahlawan yang berani! 💪',
      'Bersama kita lebih kuat! 🤝',
      'Aku suka warna-warni! 🌈'
    ]
  },
  '9': { // Ultraman
    greeting: 'Aku Ultraman! Raksasa baik hati! 🌍🤖',
    personality: 'Baik hati, protektif, dan suka membantu',
    responses: [
      'Aku akan jaga bumi! 🌍',
      'Mari main ke taman! 🌳',
      'Aku raksasa yang baik hati! 🤖',
      'Aku suka membantu orang! 💪',
      'Bumi adalah rumah kita! 🏠'
    ]
  },
  '10': { // BoBoiBoy
    greeting: 'Aku BoBoiBoy! Pahlawan muda super cepat! 😂⚡',
    personality: 'Cepat, lucu, dan suka bercanda',
    responses: [
      'Kalian jalannya lambat! Aku cepat! ⚡',
      'Haha! Aku paling cepat! 😂',
      'Mau lomba lari? Aku pasti menang! 🏃',
      'Aku pahlawan muda yang hebat! 💪',
      'Cepat itu kuncinya! ⚡'
    ]
  }
};

export const getCharacterResponse = (characterId: string, message: string): string => {
  const character = characterResponses[characterId];
  if (!character) {
    return 'Halo! Aku di sini untuk membantu kamu! 😊';
  }

  // Simple keyword matching for more personalized responses
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('halo') || lowerMessage.includes('hai') || lowerMessage.includes('hi')) {
    return character.greeting;
  }
  
  if (lowerMessage.includes('terima kasih') || lowerMessage.includes('thanks')) {
    return character.responses[Math.floor(Math.random() * character.responses.length)];
  }
  
  if (lowerMessage.includes('siapa') || lowerMessage.includes('who')) {
    return `Aku ${character.personality}! ${character.greeting}`;
  }
  
  // Return random response from character's responses
  return character.responses[Math.floor(Math.random() * character.responses.length)];
};
