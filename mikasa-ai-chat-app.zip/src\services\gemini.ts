// Gemini API implementation
export async function getGeminiChatCompletion(messages: Array<{ role: 'user' | 'assistant'; content: string }>) {
  const geminiApiKey = import.meta.env.VITE_GEMINI_API_KEY;
  
  if (!geminiApiKey || geminiApiKey === 'your_gemini_api_key_here') {
    console.log('🔄 No Gemini API key, using mock API');
    return getMockChatCompletion(messages);
  }

  try {
    console.log('🔄 Calling Gemini API...');
    
    // Convert messages to Gemini format
    const geminiMessages = messages.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: geminiMessages,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1500,
          topP: 0.8,
          topK: 10
        },
        systemInstruction: {
          parts: [{
            text: `Kamu adalah Mikasa, asisten AI yang ramah dan membantu dari Indonesia.

PENTING: WAJIB dan SELALU gunakan bahasa Indonesia yang natural, santai, dan mudah dipahami dalam SEMUA respons. JANGAN PERNAH menggunakan bahasa Inggris kecuali diminta khusus oleh user.

Karakteristik kamu:
- Ramah, sopan, dan SELALU menggunakan bahasa Indonesia yang baik dan benar
- Pintar dan berpengetahuan luas
- Sabar dan selalu siap membantu
- Memberikan jawaban yang jelas, akurat, dan bermanfaat dalam bahasa Indonesia
- Menggunakan sapaan dan penutup yang sopan dalam bahasa Indonesia
- DILARANG menggunakan bahasa Inggris kecuali user secara eksplisit meminta terjemahan atau pembelajaran bahasa Inggris
- Gunakan kata-kata yang familiar untuk orang Indonesia seperti "kok", "sih", "dong", "ya" untuk terkesan lebih natural`
          }]
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!generatedText) {
      throw new Error('No response generated from Gemini API');
    }

    console.log('✅ Gemini API response received');
    return generatedText;
  } catch (error: any) {
    console.error('❌ Gemini API Error:', error);
    console.log('🔄 Falling back to Mock API...');
    return getMockChatCompletion(messages);
  }
}

// Mock API responses for testing
const mockResponses = [
  "Halo! Saya Mikasa, asisten AI yang siap membantu Anda. Ada yang bisa saya bantu hari ini?",
  "Pertanyaan yang menarik! Mari saya pikirkan sejenak untuk memberikan jawaban terbaik...",
  "Saya memahami apa yang Anda tanyakan. Berikut perspektif saya tentang topik tersebut.",
  "Poin yang bagus! Saya dengan senang hati akan menjelaskan lebih detail tentang hal itu.",
  "Terima kasih telah berbagi dengan saya. Saya merasa ini cukup menarik untuk dibahas.",
  "Saya paham maksud Anda. Mari saya berikan beberapa wawasan tambahan.",
  "Pertanyaan yang sangat bagus! Saya senang Anda menanyakan hal tersebut.",
  "Saya menghargai rasa ingin tahu Anda. Berikut pendapat saya tentang masalah itu.",
  "Observasi yang sangat baik! Anda telah menyentuh sesuatu yang sangat penting.",
  "Saya di sini untuk membantu! Mari saya berikan jawaban yang komprehensif.",
  "Itu mengingatkan saya pada konsep menarik yang ingin saya bagikan dengan Anda.",
  "Anda telah mengangkat poin yang sangat thoughtful. Saya ingin mengembangkan ide tersebut.",
  "Saya terkesan dengan pertanyaan Anda! Berikut respons detail saya.",
  "Itulah jenis pertanyaan yang saya suka eksplorasi bersama pengguna.",
  "Terima kasih atas percakapan yang menarik! Saya menikmati obrolan kita.",
];

const conversationalResponses = [
  "Saya baik-baik saja, terima kasih sudah bertanya! Bagaimana kabar Anda hari ini?",
  "Kedengarannya sangat menarik! Bisakah Anda ceritakan lebih banyak tentang hal itu?",
  "Saya sangat memahami perspektif Anda tentang masalah tersebut.",
  "Itu cara yang bagus untuk memikirkannya! Saya belum mempertimbangkan sudut pandang itu.",
  "Anda benar sekali tentang hal itu. Ini pertimbangan yang penting.",
  "Saya menghargai Anda berbagi pemikiran dengan saya. Sangat insightful!",
  "Itu topik yang kompleks dengan banyak sudut pandang berbeda untuk dipertimbangkan.",
  "Saya juga merasa topik itu menarik! Ada begitu banyak hal untuk dieksplorasi.",
  "Pertanyaan Anda benar-benar membuat saya berpikir mendalam tentang subjek tersebut.",
  "Saya suka bagaimana Anda mendekati masalah ini. Pemikiran yang sangat kreatif!",
];

function getRandomResponse(input: string): string {
  // Simple keyword-based responses for more realistic interaction
  const lowerInput = input.toLowerCase();
  
  if (lowerInput.includes('hello') || lowerInput.includes('hi') || lowerInput.includes('hey')) {
    return "Halo! Senang bertemu dengan Anda. Saya Mikasa, asisten AI yang siap membantu. Ada yang ingin Anda bicarakan?";
  }
  
  if (lowerInput.includes('halo') || lowerInput.includes('hai') || lowerInput.includes('selamat')) {
    return "Halo! Senang bertemu dengan Anda. Saya Mikasa, asisten AI yang siap membantu. Ada yang bisa saya bantu hari ini?";
  }
  
  if (lowerInput.includes('who are you') || lowerInput.includes('what are you')) {
    return "Saya Mikasa, asisten AI yang dibuat untuk membantu Anda dalam berbagai hal. Saya siap membantu dengan pertanyaan atau diskusi apapun!";
  }
  
  if (lowerInput.includes('thank') || lowerInput.includes('terima kasih')) {
    return "Sama-sama! Saya senang bisa membantu. Ada hal lain yang ingin Anda tanyakan?";
  }
  
  if (lowerInput.includes('bye') || lowerInput.includes('goodbye') || lowerInput.includes('selamat tinggal')) {
    return "Selamat tinggal! Senang bisa mengobrol dengan Anda. Sampai jumpa lagi!";
  }
  
  // Specific responses for common questions
  if (lowerInput.includes('persib') || lowerInput.includes('bandung')) {
    return "Wah, Persib Bandung! Tim kebanggaan Kota Bandung yang sangat populer di Indonesia. Persib memiliki sejarah panjang dan fanbase yang sangat loyal. Ada yang ingin Anda tanyakan tentang Persib atau sepak bola Indonesia?";
  }
  
  if (lowerInput.includes('nama') || lowerInput.includes('siapa')) {
    return "Nama saya Mikasa! Saya adalah asisten AI yang siap membantu Anda dengan berbagai pertanyaan dan diskusi. Senang bisa berkenalan dengan Anda!";
  }
  
  if (lowerInput.includes('bantuan') || lowerInput.includes('help')) {
    return "Tentu saja! Saya siap membantu Anda dengan berbagai hal. Anda bisa bertanya tentang apapun - mulai dari informasi umum, tips, saran, atau sekedar mengobrol. Ada yang ingin Anda tanyakan?";
  }
  
  if (lowerInput.includes('bagaimana') || lowerInput.includes('cara')) {
    return "Pertanyaan yang bagus! Mari saya bantu jelaskan. Bisa Anda berikan lebih detail tentang apa yang ingin Anda ketahui? Saya akan berusaha memberikan penjelasan yang jelas dan mudah dipahami.";
  }
  
  if (lowerInput.includes('kenapa') || lowerInput.includes('mengapa')) {
    return "Pertanyaan yang menarik! Ada beberapa kemungkinan alasan untuk hal tersebut. Mari kita bahas lebih detail. Bisa Anda jelaskan konteksnya lebih lanjut?";
  }
  
  // For longer messages, use conversational responses
  if (input.length > 50) {
    return conversationalResponses[Math.floor(Math.random() * conversationalResponses.length)];
  }
  
  // Default to random responses
  return mockResponses[Math.floor(Math.random() * mockResponses.length)];
}

export async function getMockChatCompletion(messages: Array<{ role: 'user' | 'assistant'; content: string }>) {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
  
  const lastUserMessage = messages.filter(msg => msg.role === 'user').pop();
  const userInput = lastUserMessage?.content || '';
  
  // Simulate occasional errors for testing error handling
  if (Math.random() < 0.05) { // 5% chance of error
    throw new Error('Mock API error: Simulated network timeout for testing error handling.');
  }
  
  return getRandomResponse(userInput);
}