import { getMockChatCompletion } from './mockApi';

export async function getChatCompletion(messages: Array<{ role: 'user' | 'assistant'; content: string }>) {
  // Priority 1: Try Gemini API first
  const geminiApiKey = import.meta.env.VITE_GEMINI_API_KEY;
  if (geminiApiKey && geminiApiKey !== 'your_gemini_api_key_here') {
    console.log('🔄 Using Gemini API');
    try {
      const geminiModule = await import('./gemini');
      return geminiModule.getGeminiChatCompletion(messages);
    } catch (error) {
      console.error('❌ Gemini API Error:', error);
      console.log('🔄 Falling back to Mock API...');
    }
  }

  // Priority 2: Use enhanced mock API as fallback
  console.log('🔄 Using Enhanced Mock API for demo');
  return getMockChatCompletion(messages);
}